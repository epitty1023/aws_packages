============
Installation
============

At the command line::

    $ pip install awsapilib

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv awsapilib
    $ pip install awsapilib

Or, if you are using pipenv::

    $ pipenv install awsapilib

Or, if you are using pipx::

    $ pipx install awsapilib
