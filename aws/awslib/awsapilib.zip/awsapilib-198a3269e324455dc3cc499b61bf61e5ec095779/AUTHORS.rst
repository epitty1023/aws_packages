=======
Credits
=======

Development Lead
----------------

* Costas Tyfoxylos <ctyfoxylos@schubergphilis.com>

Contributors
------------

* Sjoerd Tromp <valkjes@gmail.com>
* Sayantan Khanra <skhanra@schubergphilis.com>
* Soenke Ruempler <soenke+github@ruempler.eu>
* Rafael Zamana Kineippe <rafael@zamana.com.br>
